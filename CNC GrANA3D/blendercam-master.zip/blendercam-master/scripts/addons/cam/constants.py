
# Package to store all constants of BlenderCAM

# PRECISION is used in most operations
PRECISION = 5

CHIPLOAD_PRECISION = 10

MAX_OPERATION_TIME = 3200000000 # seconds

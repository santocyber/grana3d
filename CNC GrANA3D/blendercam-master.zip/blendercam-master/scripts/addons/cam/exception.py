class CamException(Exception):
    pass
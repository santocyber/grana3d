#error "PINS_DEBUGGING is not yet supported for Teensy 3.1 / 3.2!"
